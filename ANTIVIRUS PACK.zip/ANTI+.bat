@echo off
:: --- ADMIN ELEVATION START ---
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' ( goto UACPrompt ) else ( goto gotAdmin )
:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B
:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    pushd "%cd%"
    CD /D "%~dp0"
:: --- ADMIN ELEVATION END ---

title Anti+ Security Suite
set version=3.5
set back=0
set text=A

:: --- CREATE DESKTOP LOGO ---
set "logoFile=%userprofile%\Desktop\Anti+_Logo.txt"
echo. > "%logoFile%"
echo    ___    _   __  ______  ____     __ >> "%logoFile%"
echo   /   ^|  / ^| / / /_  __/ /  _/    / /_ >> "%logoFile%"
echo  / /^| ^| /  ^|/ /   / /    / /     / __ \ >> "%logoFile%"
echo / ___ ^|/ /^|  /   / /   _/ /_    / /_/ / >> "%logoFile%"
echo/_/  ^|_/_/ ^|_/   /_/   /___/   /_.___/  >> "%logoFile%"
echo. >> "%logoFile%"
echo    [ SECURITY SUITE LOADED ] >> "%logoFile%"

:start_up
cls
color 0A
echo.
echo    ___    _   __  ______  ____     __ 
echo   /   ^|  / ^| / / /_  __/ /  _/    / /_ 
echo  / /^| ^| /  ^|/ /   / /    / /     / __ \
echo / ___ ^|/ /^|  /   / /   _/ /_    / /_/ /
echo/_/  ^|_/_/ ^|_/   /_/   /___/   /_.___/ 
echo.
echo ------------------------------------------------------
:: CALL LOADING BAR FUNCTION
set "task=Initializing Security Modules"
call :loading_bar
set "task=Checking System Integrity"
call :loading_bar
set "task=Finalizing UI"
call :loading_bar

:menu
cls
color %back%%text%
echo.
echo    ___    _   __  ______  ____     __ 
echo   /   ^|  / ^| / / /_  __/ /  _/    / /_ 
echo  / /^| ^| /  ^|/ /   / /    / /     / __ \
echo / ___ ^|/ /^|  /   / /   _/ /_    / /_/ /
echo/_/  ^|_/_/ ^|_/   /_/   /___/   /_.___/ 
echo.
echo ======================================================
echo           ANTI+ SECURITY SUITE - v%version%
echo ======================================================
echo  [1] REPAIRS, SCANS ^& MORE
echo  [2] CUSTOMIZE ANTI+ (Colors)
echo  [3] SYSTEM INFO
echo  [4] EXIT
echo ======================================================
choice /c 1234 /n /m "Select an option: "

if %errorlevel%==1 goto folder_repairs
if %errorlevel%==2 goto folder_custom
if %errorlevel%==3 goto sysinfo
if %errorlevel%==4 exit

:: --- LOADING BAR ENGINE ---
:loading_bar
echo [%task%...]
echo [IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII]
timeout /t 1 >nul
goto :eof

:: --- SUB-FOLDERS ---
:folder_repairs
cls
echo [ REPAIRS, SCANS ^& MORE ]
echo 1. Quick Scan       4. System Repair    7. DNS Flush
echo 2. Deep File Scan   5. Network Mon      8. Junk Nuker
echo 3. Process Manager  6. Privacy Wipe     0. BACK
choice /c 123456780 /n /m "Action: "

if %errorlevel%==1 (set "task=Scanning Processes" & call :loading_bar & goto quickscan)
if %errorlevel%==2 (set "task=Deep Scanning" & call :loading_bar & goto filescan)
if %errorlevel%==3 goto procmgr
if %errorlevel%==4 (set "task=Repairing Registry" & call :loading_bar & goto repair)
if %errorlevel%==5 goto netmon
if %errorlevel%==6 (set "task=Wiping Temp Files" & call :loading_bar & goto privacy)
if %errorlevel%==7 (set "task=Flushing DNS" & call :loading_bar & goto dnsflush)
if %errorlevel%==8 (set "task=Nuking Junk" & call :loading_bar & goto nuker)
if %errorlevel%==9 goto menu

:: --- CORE FUNCTIONS ---
:quickscan
cls
tasklist | findstr /i "miner.exe virus.exe" || echo [CLEAN] No threats detected.
pause
goto folder_repairs

:repair
cls
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /t REG_DWORD /d 0 /f
echo [DONE] System restrictions removed.
pause
goto folder_repairs

:dnsflush
cls
ipconfig /flushdns
echo [DONE] DNS Cache Flushed.
pause
goto folder_repairs

:nuker
cls
del /f /s /q %systemdrive%\*.tmp >nul
echo [DONE] Junk files removed.
pause
goto folder_repairs

:folder_custom
cls
echo [1] Text Color  [2] Background Color  [0] Back
choice /c 120 /n /m "Pick: "
if %errorlevel%==1 goto pick_text
if %errorlevel%==2 goto pick_back
if %errorlevel%==3 goto menu

:pick_text
cls
echo 1. Green 2. Blue 3. Red 4. White
choice /c 1234 /n /m "Pick: "
if %errorlevel%==1 set text=A
if %errorlevel%==2 set text=9
if %errorlevel%==3 set text=C
if %errorlevel%==4 set text=F
goto folder_custom

:pick_back
cls
echo 1. Black 2. Dark Blue 3. Grey 4. Bright White
choice /c 1234 /n /m "Pick: "
if %errorlevel%==1 set back=0
if %errorlevel%==2 set back=1
if %errorlevel%==3 set back=8
if %errorlevel%==4 set back=F
goto folder_custom

:sysinfo
cls
wmic os get Caption
pause
goto menu