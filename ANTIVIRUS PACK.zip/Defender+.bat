@echo off
title Defender+ Antivirus & Security Suite v3.0
setlocal enabledelayedexpansion
color 0B

:: --- INITIALIZATION ---
if not exist "SCANS" mkdir "SCANS"
if not exist "C:\DefenderPlus_Quarantine" mkdir "C:\DefenderPlus_Quarantine"
if not exist "SCANS\signatures.txt" (
    echo virus.exe > "SCANS\signatures.txt"
    echo malware.vbs >> "SCANS\signatures.txt"
    echo ransom.js >> "SCANS\signatures.txt"
    echo trojan.bat >> "SCANS\signatures.txt"
)

:menu
cls
echo ======================================================
echo           DEFENDER+ SECURITY SUITE v3.0
echo ======================================================
echo  [1] Quick Scan         [5] System Optimizer (Clean)
echo  [2] Full System Scan   [6] Network Security Check
echo  [3] Custom Folder Scan [7] Restore from Quarantine
echo  [4] View Logs          [8] Exit
echo ======================================================
set /p choice="Select an option (1-8): "

if %choice%==1 set "target=." & goto engine
if %choice%==2 set "target=C:\" & goto engine
if %choice%==3 goto custom_scan
if %choice%==4 goto quarantine_view
if %choice%==5 goto optimizer
if %choice%==6 goto net_check
if %choice%==7 goto restore_file
if %choice%==8 exit
goto menu

:: --- SCAN ENGINE ---
:engine
cls
echo [*] DEFENDER+ ENGINE STARTING...
echo ------------------------------------------------------
for /r "%target%" %%f in (*.exe *.vbs *.js *.bat *.com *.txt) do (
    set "flagged=0"
    for /f "usebackq tokens=*" %%s in ("SCANS\signatures.txt") do (
        if /i "%%~nxf"=="%%s" (set "flagged=1" & set "reason=Signature Match")
    )
    echo %%~nxf | findstr /i "password creditcard hack login" >nul
    if !errorlevel!==0 (set "flagged=1" & set "reason=Heuristic Keyword")

    if "!flagged!"=="1" (
        echo [!!!] THREAT: %%~nxf [!reason!]
        move "%%f" "C:\DefenderPlus_Quarantine\" >nul 2>&1
        echo [%date% %time%] FOUND: %%f >> "C:\DefenderPlus_Quarantine\log.txt"
    ) else (
        echo [OK] %%~nxf
    )
)
pause
goto menu

:: --- SYSTEM OPTIMIZER (NEW!) ---
:optimizer
cls
echo [!] Cleaning Temporary Files to improve security...
del /s /f /q %temp%\*.* >nul 2>&1
rd /s /q %temp% >nul 2>&1
mkdir %temp%
echo [OK] Temporary files cleared.
echo [!] Flushing DNS cache to prevent redirection hijacks...
ipconfig /flushdns >nul
echo [OK] DNS Cache Flushed.
pause
goto menu

:: --- NETWORK CHECK (NEW!) ---
:net_check
cls
echo [!] Listing all active internet connections...
echo [!] Look for suspicious IP addresses or unknown apps.
echo.
netstat -ano | findstr "ESTABLISHED"
echo.
echo ------------------------------------------------------
echo (PID is the Process ID. Check Task Manager to see which app it is.)
pause
goto menu

:: --- RESTORE TOOL (NEW!) ---
:restore_file
cls
echo --- QUARANTINE ITEMS ---
dir "C:\DefenderPlus_Quarantine" /b /a-d
echo.
set /p rfile="Enter the EXACT filename to restore (or 'back'): "
if "%rfile%"=="back" goto menu
if exist "C:\DefenderPlus_Quarantine\%rfile%" (
    move "C:\DefenderPlus_Quarantine\%rfile%" "." >nul
    echo [OK] File restored to current folder.
) else (
    echo [ERROR] File not found in quarantine.
)
pause
goto menu

:custom_scan
cls
set /p target="Enter folder path to scan: "
if not exist "%target%" (echo Folder not found! & pause & goto menu)
goto engine

:quarantine_view
cls
echo --- SCAN LOGS ---
if exist "C:\DefenderPlus_Quarantine\log.txt" type "C:\DefenderPlus_Quarantine\log.txt"
pause
goto menu